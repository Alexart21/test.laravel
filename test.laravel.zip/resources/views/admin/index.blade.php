<x-layouts.admin title="Админка | главная">
<h3>Админка</h3>
    <a href="https://github.com/Alexart21/test.laravel" target="_blank">View GitHub</a>
</x-layouts.admin>
