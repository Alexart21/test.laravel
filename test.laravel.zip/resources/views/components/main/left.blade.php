<ul style="margin-right: 2em">
    <li><a href="{{ route('admin.index') }}">главная</a></li>
    <li><a href="{{ route('products.index') }}">товары</a></li>
    <li><a href="{{ route('orders.index') }}">заказы</a></li>
    <li><a href="{{ route('admin.api') }}">api test</a></li>
</ul>
