<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['title' => 'API test']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'API test']); ?>
    <h3>Udate test order id = <?php echo e($order->id); ?></h3>

    <form id="test-form" action="" method="post" name="test-form">
        <?php echo method_field('POST'); ?>
        <input type="hidden" name="id" value="<?php echo e($order->id); ?>">
        <div class="form-group">
            <label for="date">Дата вида 01.02.2023</label>
            <input id="date" class="form-control" type="text" name="date" value="<?php echo e($order->date); ?>">
            <div id="date-err-index" class="err-msg text-danger"></div>
        </div>

        <div class="form-group">
            <label for="phone">Номер телефона:</label>
            <input id="phone" class="form-control" type="text" name="phone" value="<?php echo e($order->phone); ?>">
            <div id="phone-err-index" class="err-msg text-danger"></div>
        </div>

        <div class="form-group">
            <label for="">Email:</label>
            <input type="email" class="form-control" name="email" value="<?php echo e($order->email); ?>">
            <div id="email-err-index" class="err-msg text-danger"></div>
        </div>

        <div class="form-group">
            <label for="">Адрес:</label>
            <input type="text" class="form-control" name="address" value="<?php echo e($order->address); ?>">
            <div id="address-err-index" class="err-msg text-danger"></div>
        </div>
        <button class="btn btn-success">Отправить</button>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

<script>
    let form = document.getElementById('test-form');
    form.onsubmit = async (e) => {
        e.preventDefault();
        let errs = document.querySelectorAll('.err-msg');
        for(let i = 0; i < errs.length; i++){ // очистим поля ошибок
            errs[i].innerHTML = '';
        }
        let jwt = JSON.parse(localStorage.getItem('jwt'));
        if (!jwt) {
           alert('Получите токен!');
           return;
        }
        let formData = new FormData(form);
        let response = await fetch("<?php echo e(route('api.update')); ?>", {
            method: 'POST',
            headers: {
                // 'Content-Type': 'application/json;charset=utf-8',
                'Authorization': jwt.token_type + ' ' + jwt.access_token
            },
            body: formData
        });
        if (!response.ok) {
            console.log(response);
            if (response.status == 422) { // ошибки валидации
                result = await response.json();
                console.log('validate errors');
                let errors = result.errors;
                for (let key in errors) {
                    try {
                        let errBlock = document.getElementById(key + '-err-index');
                        errBlock.innerText = errors[key][0];
                    } catch (e) {
                        continue;
                    }
                }
            }
        }else{
            let result = await response.json();
            console.log(result)
        }
    }
</script>
<?php /**PATH C:\Alex\OpenServer\domains\test.laravel\resources\views/admin//update.blade.php ENDPATH**/ ?>