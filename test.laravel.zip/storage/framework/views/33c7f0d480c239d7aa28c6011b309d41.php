<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['title' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => '']); ?>
    <h2>Заказ № <?php echo e($order->id); ?></h2>
    <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <table class="admin_tbl">
        <tr>
            <th> Id</th>
            <th> Дата</th>
            <th>Телефон</th>
            <th>Email</th>
            <th>Адрес</th>
            <?php if($order->total): ?>
            <th>Итог</th>
            <?php endif; ?>
        </tr>
        <tr>
            <td><?php echo e($order->id); ?></td>
            <td><?php echo e($order->date); ?></td>
            <td><?php echo e($order->phone); ?></td>
            <td><?php echo e($order->email); ?></td>
            <td><?php echo e($order->address); ?></td>
            <?php if($order->total > 0): ?>
            <td><?php echo e($order->total); ?></td>
            <?php endif; ?>
        </tr>
    </table>
    <br>
    <?php if($order->total <= 0): ?>
        <h4>Товаров в заказе нет</h4>
        <form action="<?php echo e(route('orders.delete', [$order->id])); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button class="btn btn-danger">удалить заказ</button>
        </form>
        <br>
    <?php else: ?>
        <h4>Товары в заказе (условная корзина)</h4>
        <table class="admin_tbl">
            <tr>
                <th>Наименование</th>
                <th>Цена</th>
                <th>Количество</th>
                <th>Сумма</th>
                <th>Действие</th>
            </tr>

        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($product->title); ?></td>
                <td><?php echo e($product->price); ?></td>
                <td><?php echo e($product->qty); ?></td>
                <td><?php echo e($product->total); ?></td>
                <td>
                    <form action="<?php echo e(route('orders.destroy', [ $product->id ])); ?>" method="post" class="del-form">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="del-bt"><svg xmlns="http://www.w3.org/2000/svg" id="mdi-trash-can" viewBox="0 0 24 24" class="red-icon"><path d="M9,3V4H4V6H5V19A2,2 0 0,0 7,21H17A2,2 0 0,0 19,19V6H20V4H15V3H9M9,8H11V17H9V8M13,8H15V17H13V8Z"/></svg></button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    <?php endif; ?>
    <a href="<?php echo e(route('orders.add', [ $order->id ])); ?>" class="btn btn-primary">Добавить товар</a>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php /**PATH C:\Alex\OpenServer\domains\test.laravel\resources\views/admin/orders/show.blade.php ENDPATH**/ ?>