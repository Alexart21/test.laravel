<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['title' => 'Заказы']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Заказы']); ?>
<h2>Заказы</h2>
    <a href="<?php echo e(route('orders.create')); ?>" class="btn btn-primary">создать</a>
    <br>
    <br>
    <?php if($total): ?>
        <table class="admin_tbl">
            <tr>
                <th>Id</th>
                <th>Дата</th>
                <th>Телефон</th>
                <th>Email</th>
                <th>Адрес</th>
                <th>Сумма</th>
                <th>Действия</th>
            </tr>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($order->id); ?></td>
                <td><?php echo e($order->date); ?></td>
                <td><?php echo e($order->phone); ?></td>
                <td><?php echo e($order->email); ?></td>
                <td><?php echo e($order->address); ?></td>
                <td><?php echo e($order->total); ?></td>
                <td>
                    <a href="<?php echo e(route('orders.show', [ $order->id ])); ?>"><svg xmlns="http://www.w3.org/2000/svg" id="mdi-eye" viewBox="0 0 24 24" class="blue-icon"><path d="M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9M12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17M12,4.5C7,4.5 2.73,7.61 1,12C2.73,16.39 7,19.5 12,19.5C17,19.5 21.27,16.39 23,12C21.27,7.61 17,4.5 12,4.5Z"/></svg></a>
                    <a href="<?php echo e(route('orders.edit', [ $order->id ])); ?>"><svg xmlns="http://www.w3.org/2000/svg" id="mdi-pencil" viewBox="0 0 24 24" class="green-icon"><path d="M20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29C18,2.9 17.35,2.9 16.96,3.29L15.12,5.12L18.87,8.87M3,17.25V21H6.75L17.81,9.93L14.06,6.18L3,17.25Z"/></svg></a>
                    <form action="<?php echo e(route('orders.delete', [$order->id])); ?>" method="post" class="del-form">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="del-bt"><svg xmlns="http://www.w3.org/2000/svg" id="mdi-trash-can" viewBox="0 0 24 24" class="red-icon"><path d="M9,3V4H4V6H5V19A2,2 0 0,0 7,21H17A2,2 0 0,0 19,19V6H20V4H15V3H9M9,8H11V17H9V8M13,8H15V17H13V8Z"/></svg></button>
                    </form>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    <?php else: ?>
        <h3>Заказов нет</h3>
    <?php endif; ?>
    <br>
    <?php echo e($orders->links('vendor.pagination.bootstrap-4')); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php /**PATH C:\Alex\OpenServer\domains\test.laravel\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>