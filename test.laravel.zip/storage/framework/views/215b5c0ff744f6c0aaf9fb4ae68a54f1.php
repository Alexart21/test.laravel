<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['title' => 'Добавление товара']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Добавление товара']); ?>
<h2>Добавление товаров для заказа № <?php echo e($order->id); ?></h2>
    <?php if($order->total): ?>
         Сумма: <?php echo e($order->total); ?>

    <?php endif; ?>
    <form id="add-form" action="<?php echo e(route('orders.save')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>">
    <div class="form-group">
        <label for="product">Начните вводить название товара</label>
        <input id="product" list="product_list" class="form-control"  type="text" name="product">
        <datalist id="product_list">
        </datalist>
        <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div class="form-group">
            <label for="qty">Количество</label>
            <input id="qty" type="number" name="qty" value="1">
        </div>
    </div>
        <button class="btn btn-success">добавить</button>
    </form>
    <?php if($order->total): ?>
        <a href="<?php echo e(route('orders.show', [$order->id])); ?>" class="btn btn-primary">Завершить</a>
    <?php endif; ?>
    <script>
        let inp = document.getElementById('product');
        let datalist = document.getElementById('product_list');
        let addrForm = document.getElementById('add-form');
        let productId = document.getElementById('product_id');
        inp.addEventListener('input', (e) => {
            q = e.target.value;
            if (q.length > 2) { // со скольки букв начинать живой поиск
                // console.log('here');
                fetchData(addrForm);
            }
        });

        async function fetchData(form){
            let formData = new FormData(form);
            let response = await fetch("<?php echo e(route('orders.search')); ?>", {
                method: 'POST',
                body: formData
            });
            if (!response.ok) {
                console.log(response);
            } else {// статус 200
                result = await response.json();
                if (result.success) { // успешно
                    let product = result.product;
                    console.log(product)
                    if (product) {
                        datalist.innerHTML = '';
                        let arr = result.product;
                        arr.map((item) => {
                            let option = document.createElement('option');
                            option.value = item.title;
                            datalist.prepend(option);
                        })
                    }
                } else { // фиг знает че за ошибка
                    console.log(response);
                }
            }
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php /**PATH C:\Alex\OpenServer\domains\test.laravel\resources\views/admin/orders/addProduct.blade.php ENDPATH**/ ?>