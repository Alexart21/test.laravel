<ul style="margin-right: 2em">
    <li><a href="<?php echo e(route('admin.index')); ?>">главная</a></li>
    <li><a href="<?php echo e(route('products.index')); ?>">товары</a></li>
    <li><a href="<?php echo e(route('orders.index')); ?>">заказы</a></li>
    <li><a href="<?php echo e(route('admin.api')); ?>">api test</a></li>
</ul>
<?php /**PATH C:\Alex\OpenServer\domains\test.laravel\resources\views/components/main/left.blade.php ENDPATH**/ ?>