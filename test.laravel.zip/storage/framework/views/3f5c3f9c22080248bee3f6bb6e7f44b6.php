<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'id',
    'date',
    'phone',
    'email',
    'address'
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'id',
    'date',
    'phone',
    'email',
    'address'
]); ?>
<?php foreach (array_filter(([
    'id',
    'date',
    'phone',
    'email',
    'address'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<form id="test-form" action="" method="post" name="test-form">
    <?php echo method_field('POST'); ?>
    <input type="hidden" name="id" value="<?php echo e($id); ?>">
    <div class="form-group">
        <label for="date">Дата вида 01.02.2023</label>
        <input id="date" class="form-control" type="text" name="date" value="<?php echo e($date); ?>">
        <div id="date-err-index" class="err-msg text-danger"></div>
    </div>

    <div class="form-group">
        <label for="phone">Номер телефона:</label>
        <input id="phone" class="form-control" type="text" name="phone" value="<?php echo e($phone); ?>">
        <div id="phone-err-index" class="err-msg text-danger"></div>
    </div>

    <div class="form-group">
        <label for="">Email:</label>
        <input type="email" class="form-control" name="email" value="<?php echo e($email); ?>">
        <div id="email-err-index" class="err-msg text-danger"></div>
    </div>

    <div class="form-group">
        <label for="">Адрес:</label>
        <input type="text" class="form-control" name="address" value="<?php echo e($address); ?>">
        <div id="address-err-index" class="err-msg text-danger"></div>
    </div>
    <button class="btn btn-success">Отправить</button>
</form>
<?php /**PATH C:\Alex\OpenServer\domains\test.laravel\resources\views/components/ui/api/order-form.blade.php ENDPATH**/ ?>